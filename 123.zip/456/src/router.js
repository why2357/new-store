import { createRouter, createWebHashHistory } from "vue-router";
import loginVue from "./components/login.vue";
import HomeVue from "./components/home.vue";
import workVue from "./components/work.vue";


const routes = [
  {
    path: "/home",
    name: "home",
    component: HomeVue,
  },
  {
    path: "/login",
    name: "login",
    component: loginVue,
  },
  {
    path: "/work",
    name: "work",
    component: workVue,
  },
];
const router = createRouter({
  history: createWebHashHistory(),
  routes,
});

export default router;