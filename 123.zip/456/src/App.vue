<script setup>

</script>

<template>
  <div>
   
    <br>
    <router-link to="/login">切换到登录</router-link><br>
    
    <router-view></router-view>
    
  
</div>
 
</template>


