<script >
import axios from 'axios'
import { selectGroupKey } from 'element-plus'
import { ref } from 'vue'

const username = ref(null)//初始化为null
const password = ref(null)
const count = ref(0)

// var login=document.getElementById("login") ;//脚本里面绑定按钮
// function login(){
//已有用户登录，先让服务器给我token,
//     axios.post(`http://148.100.79.89:5000/token`,{
//       username:`${username.value}`,
//       password:`${password.value}`
//     })
//     .then(r =>{
//       console.log(r);
//     })

// }


export default{ 
  
  name:'login',
  data(){  
    return{
        username:"",
        password:""
      }
  },
  
  //methon是一个对象，里面可以有很多属性，如名字，还可以有方法，如函数login（）
  methods:{ 
    login(){            //登录函数
      if(this.username == "why"
      && this.password == "123"){    //将来这里hui变成和后端返回数据的验证
            this.$router.push("/home")
            console.log(`试试${username.value},${password.value}`)
          }else{ 
            alert("密码或用户名错误")
          }
    },
    enroll:function(){                   //注册函数
      console.log(`试试${username.value},${password.value}`)
      if(username.value != null && password.value != null){
        axios.post(`http://148.100.79.89:5000/user?`,{
  username: `${username.value}`,
  password: `${password.value}`,
  })
  .then(r => {
      console.log(r)
    })
}
    else
    {
      alert("输入不能为空！");
    }
    }
  },
  
}


</script>

<template>
  <div class="login_class">
    
    <form @submit.prevent="login">
      用户：<input type="text"   v-model="username" placeholder="账号" ><br>
      密码：<input type="password"   v-model="password" placeholder="密码" ><br>
      <!-- <el-button   @onclick="login"  type="primary"  plain>登录</el-button><br> -->
      <el-button   @click="login"  type="primary"  plain>登录</el-button><br>
      <el-button   @click="enroll" type="primary"  plain>注册</el-button>
      <button type="button" @click="count++">count is {{ count }}</button>
    </form>
    <!-- primary好像是elemate的自定义属性 -->
  </div>
  <p>Message is: {{ username }}</p>
  <p>Message is: {{ password }}</p>
</template>



<style>
.login_class{
     width: 1000px;
    height: 500px;
    overflow: hidden;/*超出容器的隐藏*/
    position: relative;
    background-image: url("src/images/1.png");
    /* background-color: blue; */
    background-repeat: no-repeat;
    background-size: cover;
}


</style>
 

