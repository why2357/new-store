<script setup>
import axios from 'axios'
// import { Header } from 'element-plus/es/components/table-v2/src/components'
import { ref } from 'vue'

const grade = ref(null)
const bedroom = ref(null)
const week_id = ref(null)
const weeks = ref(null)
const rating = ref(null)
const username = ref(null)
const password = ref(null)
const grant_type = ''
const scope = ''
const client_id = ''
const client_secret = ''


var redata = 0;  
 function add (){
    if(grade.value != null && bedroom.value != null&& week_id.value != null&& weeks.value!= null && rating.value != null){
        axios.post(`http://148.100.79.89:5000/main/add?`,{
      //  data: {  

  // grade: "{String(grade.value)}" ,
  // bedroom:String(bedroom.value),
  // week_id:Number(week_id.value),
  // weeks: String(weeks.value),
  //  rating: String(rating.value),
   
  "grade": `${grade.value}`,
  "bedroom": `${bedroom.value}`,
  "week_id": week_id.value,
  "weeks": `${weeks.value}`,
  "rating": `${rating.value}`,

        //  },
      // headers: {
      //   ContentType: 'application/json',
      //   accept: 'application/json'  
      //           }
  })
  .then(r => {
      console.log(r)
    })
}
    else
    {
      alert("输入不能为空！");
    }
  }
// console.log(typeof(grade.value),typeof(bedroom.value),typeof(week_id.value),typeof(weeks.value),typeof(rating.value))
  


function queryall(){  
  axios.get(`http://148.100.79.89:5000/main/query?page=1&limit=10`)
  .then(ret =>{
    //  console.log(ret);   
    redata =ret.data;
    console.log(redata)
  })
}

function enroll(){  
  console.log(typeof(username.value),typeof(password.value))
  console.log(username.value,password.value)
  axios.post(`http://148.100.79.89:5000/user?username=${username.value}&password=${password.value}`,{
    // username: `${username.value}`,
    // password: `${password.value}`,     
    headers: {accept: 'application/json'}  
  },
 )
  .then(ret =>{  
    redata =ret.data;
    console.log(redata)
  })
}


function token(){  
  console.log(`试试${username.value},${password.value}`)
  console.log(typeof(grant_type.value),typeof(scope.value))
  console.log(typeof(client_id.value),typeof(client_secret.value))
  axios.post(`http://148.100.79.89:5000/token`,{
    // grant_type: `${grant_type.value}`,
    username: `${username.value}`,
    password: `${password.value}`,
    // scope: `${scope.value}`,
    // client_id: `${client_id.value}`,
    // client_secret:` ${client_secret.value}`,
  //   headers: {
  //     'accept': 'application/json',
  //     'Content-Type': 'application/x-www-form-urlencoded', 
  // },  
  })
  .then(ret =>{
    //  console.log(ret);   
    redata =ret.data;
    console.log(redata)
  })
}

// export default{
//     name:'work',
// }

</script>

<template>

     <div>
    
    年纪：<input type="text" v-model="grade" ><br>
    寝室：<input type="text" v-model="bedroom" ><br>
    第几周：<input type="text" v-model="week_id" ><br>
    星期：<input type="text" v-model="weeks" ><br>
    评价：<input type="text" v-model="rating" ><br>
    <!-- 用户：<input type="text" v-model="username" ><br>
    密码：<input type="password" v-model="password" ><br> -->
    <button @click="add()" >增加</button><br>
    <button @click="queryall()">查询所有</button><br>
    <button @click="token()">看token</button><br>
    <!-- <button @click="enroll()">注册</button><br> -->

    </div>
</template>
  
