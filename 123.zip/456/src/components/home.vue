<template>  
        <p>登录成功</p>
      
      <router-link to="/work">切换到work</router-link><br>
      
 
  </template>
  
<script >
export default{
    name:'home',//给组件起名字，为啥login不用

}

</script>